def criar_matriz():
    criacaoMatriz = True
    while criacaoMatriz:
        linhas = int(input('Digite o número de linhas: '))
        colunas = int(input('Digite o número de colunas: '))
        print('-' * 30)
        if (linhas <= 0):
            print('NÃO EXISTE MATRIZ COM NÚMERO DE LINHAS MENOR OU IGUAL A ZERO!')
            print('-' * 30)
        elif (colunas <= 0):
            print('NÃO EXISTE MATRIZ COM NÚMERO DE COLUNAS MENOR OU IGUAL A ZERO!')
            print('-' * 30)
        else:
            criacaoMatriz = False

    # criando a matriz
    matriz = []
    for l in range(0, linhas):
        linhaMatriz = []
        for c in range(0, colunas):
            linhaMatriz.append(0)
        matriz.append(linhaMatriz)
    return(matriz)

def visualizar_memoria(matriz):
    for n in range(0, len(matriz)):
        print(matriz[n])

def alocacao_first_fit(matriz):
    tamanhoCondicao = False
    while (tamanhoCondicao == False):
        tamanho = int(input('Digite o tamanho para a alocacao: '))
        if (tamanho <= 0):
            print('TAMANHO INVÁLIDO, DIGITE NOVAMENTE!')
            print('-' * 30)
        else:
            tamanhoCondicao = True
    alocacao = False
    cordenadas = []
    # iremos procurar o primeiro espaço em que a alocação possa ser feita
    for l in range(0, len(matriz)):
        for c in range(0, len(matriz[0])):
            if (alocacao == False):
                if (matriz[l][c] == 0):
                    cordenadas.append([l, c])
                else:
                    cordenadas = []
                if (len(cordenadas) >= tamanho):
                    for cords in cordenadas:
                        matriz[cords[0]][cords[1]] = 1
                    alocacao = True
    # caso não encontre um lugar para alocar
    if (alocacao == False):
        print('NÃO TEM ESPAÇO PARA ALOCAÇÃO NA MEMÓRIA!')
    else:
        print('ALOCAÇÃO EFETUADA COM SUCESSO!')
    return matriz

def alocacao_best_fit(matriz):
    tamanhoCondicao = False
    while (tamanhoCondicao == False):
        tamanho = int(input('Digite o tamanho para a alocacao: '))
        if (tamanho <= 0):
            print('TAMANHO INVÁLIDO, DIGITE NOVAMENTE!')
            print('-' * 30)
        else:
            tamanhoCondicao = True
    cordenadas = []
    lugares = []
    # iremos alocar no melhor espaço encontradado, para isso iremos ver todos os espaços existentes na matriz
    for l in range(0, len(matriz)):
        for c in range(0, len(matriz[0])):
            if (matriz[l][c] == 0):
                cordenadas.append([l, c])
            else:
                lugares.append(cordenadas)
                cordenadas = []

    # agora, iremos alocar no melhor espaço possível
    alocacao = False
    n = -1
    while (alocacao == False):
        n += 1
        for l in range(0, len(lugares)):
            if (alocacao == False):
                if (len(lugares[l]) == tamanho + n):
                    for lu in lugares[l]:
                        matriz[lu[0]][lu[1]] = 1
                    alocacao = True
        # caso não encontre um lugar para alocar
        if ((tamanho + n) > (len(matriz) * len(matriz[0]))):
            alocacao = True
            print('NÃO TEM ESPAÇO PARA ALOCAÇÃO NA MEMÓRIA!')
    if (alocacao == True):
        print('ALOCAÇÃO EFETUADA COM SUCESSO!')
    return matriz

def alocacao_worst_fit(matriz):
    tamanhoCondicao = False
    while (tamanhoCondicao == False):
        tamanho = int(input('Digite o tamanho para a alocacao: '))
        if (tamanho <= 0):
            print('TAMANHO INVÁLIDO, DIGITE NOVAMENTE!')
            print('-' * 30)
        else:
            tamanhoCondicao = True
    cordenadas = []
    lugares = []
    maiorEspaco = []
    # primeiro iremos ver o tamanho dos espaços
    for l in range(0, len(matriz)):
        for c in range(0, len(matriz[0])):
            if (matriz[l][c] == 0):
                cordenadas.append([l, c])
            else:

                # para saber qual o maior espaço, sempre que calcular um tamanho iremos comparar com o anterior
                lugares.append(cordenadas)
                if (len(lugares) > 1):
                    if (len(maiorEspaco) < len(cordenadas)):
                        maiorEspaco = cordenadas
                else:
                    maiorEspaco = cordenadas

                cordenadas = []

    if (cordenadas != [] and maiorEspaco == []): # caso a memória(matriz) inteira esteja livre
        for n in cordenadas:
            matriz[n[0]][n[1]] = 1
    elif (lugares == [] and cordenadas == []):
        print('NÃO TEM ESPAÇO PARA ALOCAÇÃO NA MEMÓRIA!')
    else:
        # após descobrir o maior espaço, substituiremos nas respectivas cordenadas
        for n in maiorEspaco:
            matriz[n[0]][n[1]] = 1
    return matriz

def desalocacao(matriz):
    desalocacao = False
    while (desalocacao == False):
        condicoes = False
        while  (condicoes == False):
            print('CORDENADA INICIAL PARA A DESALOCAÇÃO')
            linhaInicial = int(input('Digite a linha: '))
            colunaInicial = int(input('Digite a coluna: '))
            print('-' * 30)
            print('CORDENADA FINAL PARA A DESALOCAÇÃO')
            linhaFinal = int(input('Digite a linha: '))
            colunaFinal = int(input('Digite a coluna: '))
            print('-' * 30)
            if (linhaInicial <= 0 or colunaInicial <= 0 or linhaInicial > len(matriz) or colunaInicial > len(matriz[0])):
                print('CORDENADA INICIAL INCORRETA!')
                print('-' * 30)
            elif (linhaFinal < 0 or colunaInicial <= 0 or linhaFinal > len(matriz) or colunaFinal > len(matriz[0])):
                print('CORDENADA FINAL INCORRETA!')
                print('-' * 30)
            else:
                condicoes = True

        linhaInicial -= 1
        colunaInicial -= 1

        # coletando todas as cordenadas
        cordenadas = []
        # caso as cordenadas estejam na mesma linha
        if (linhaInicial + 1 == linhaFinal):
            for c in range(colunaInicial, colunaFinal):
                cordenadas.append([linhaInicial, c])
        # caso as cordenadas estejam em linhas diferentes
        else:
            # pegar as cordenadas desde a cordenada inicial para desalocação até o fim da linha inicial
            for c in range(colunaInicial, len(matriz[0])):
                cordenadas.append([linhaInicial, c])
            # pegar as cordenadas desde o início da linha final até a cordenada final para desalocação
            for c in range(0, colunaFinal):
                cordenadas.append([linhaFinal, c])
            # agora, se a diferença entre a linha final e a linha inicial for maior que 1, irá registrar todas
            # as cordenadas entre ambas
            if ((linhaFinal) - (linhaInicial + 1) > 1 ):
                for l in range(linhaInicial + 1, linhaFinal):
                    for c in range(0, len(matriz[0])):
                        cordenadas.append(l, c)

        # com todas as cordenadas registradas, iremos verificar se todas estão alocadas
        alocado = 0
        for cords in cordenadas:
            if (matriz[cords[0]][cords[1]] == 0):
                alocado += 1
        if (alocado > 0):
            print("NÃO É POSSIVEL DESALOCAR UMA ÁREA COM ALGUMA PARTE NÃO ALOCADA")
            print("DIGITE NOVAMENTE")
            print('-' * 30)
        else:
            # caso todas as linhas estejam alocadas, irá desalocar a memória nas respectivas cordenadas
            for cords in cordenadas:
                matriz[cords[0]][cords[1]] = 0
            desalocacao = True
    return matriz

matrizExemplo = [[1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0],
                 [0, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1],
                 [0, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1],
                 [1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1],
                 [0, 0, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0]]

# menu
matriz = []
menu = True
print('BEM VINDO AO SIMULADOR DE ALOCAÇÃO DE MEMÓRIA')
print('-' * 30)
while menu:
    print('-' * 30)
    print('1 - Usar matriz do exemplo do exercício(pdf)')
    print('2 - Criar matriz')
    if (matriz != []):
        print('3 - Visualizar a matriz')
        print('4 - Alocação first fit')
        print('5 - Alocação best fit')
        print('6 - Alocação worst fit')
        print('7 - Desalocação')
    n = int(input('Selecione uma das opções: '))
    print('-' * 30)
    if (n < 1 or n > 7 or (matriz == [] and n > 3)):
        print('OPÇÃO INVÁLIDA')
    elif (n == 1):
        matriz = matrizExemplo
    elif (n == 2):
        matriz = criar_matriz()
    elif (n == 3):
        visualizar_memoria(matriz)
    elif (n == 4):
        matriz = alocacao_first_fit(matriz)
    elif (n == 5):
        matriz = alocacao_best_fit(matriz)
    elif (n == 6):
        matriz = alocacao_worst_fit(matriz)
    else:
        matriz = desalocacao(matriz)

